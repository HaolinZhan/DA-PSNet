clear all
clc
close all

p_dd=linspace(-14.3796,7.9433,20773);
p_dd3=linspace(-14.3796,7.9433,8184);

load('proton_1d.mat');
 % initialization 
dt=real(NmrData.SPECTRA);% processed experimental data

dt=flipud(dt);

cs=NmrData.Specscale;     % chemical shift
dt=dt/max(dt);
figure (1) 
plot(p_dd,dt);  hold on
xlim([-5.6,-0.1]);
ylim([-0.01,0.66]);

load('Fully_and_sparsely_sampled.mat')
a=idealreal(:,1).';
a=a/max(a);
a1=originrealsp(:,1).';
a1=a1/max(a1);

load('IST_5%.mat')
a2=norm_origin_sp_real11;

load('DA_PSNet_5%.mat')
b=normdd3;
clear result

load('DA_PSNet_16%.mat')
c=result(:,1).';
c=c/max(c);
clear result

load('DA_PSNet_25%.mat')
d=result(:,1).';
d=d/max(d);
clear result


figure (2) 
plot(p_dd3,a-0.2);  hold on
plot(p_dd3,a1-1.2);  hold on
plot(p_dd3,a2-2.2);  hold on
plot(p_dd3,b-3.2);  hold on
plot(p_dd3,c-4.2);  hold on
plot(p_dd3,d-5.2); xlim([-5.6,-0.1]);
